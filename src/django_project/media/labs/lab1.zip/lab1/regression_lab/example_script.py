

z = 3 + 4
print(z)