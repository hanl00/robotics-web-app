print("python")
`